# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-

__license__ = 'GPL 3'
__copyright__ = '2011, Jesse Chisholm <jesse.chisholm@gmail.com>'
__docformat__ = 'restructuredtext en'

from common import DEBUG
from common import VERBOSE
from common import log

if VERBOSE:
    log.debug("AudioBookReader.__init__: __file__   : %s" % (__file__))
    log.debug("AudioBookReader.__init__: __package__: %s" % (__package__))

######################################################
######################################################

if __name__ == "__main__":
    import sys
    from reader import main
    main(sys.argv[1:])

from reader import AudioBookMetadataReader
