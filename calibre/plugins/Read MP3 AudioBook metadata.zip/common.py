# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-

__license__ = 'GPL 3'
__copyright__ = '2011, Jesse Chisholm <jesse.chisholm@gmail.com>'
__docformat__ = 'restructuredtext en'

AUDIOBOOK_KNOWN_GENRE     = ["Audiobook", "Audio Book", "Speech"]

# specify logging for DEBUG
#
import logging
log = logging.getLogger("mp4file")

# # FOR DEBUGGING:
# log_h = logging.FileHandler("C:/Users/Jesse/calibre_hold/dev/AudioBookReader/_debug.log")
# log_f = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
# log_h.setFormatter(log_f)
# log.setLevel(logging.DEBUG)

# FOR RELEASE:
class NullHandler(logging.Handler):
    def emit(self, record):
        pass
log_h = NullHandler()

log.addHandler(log_h)
log.setLevel(logging.NOTSET)

DEBUG = 0
VERBOSE = 0

if VERBOSE:
    log.debug("AudioBookReader.common: __file__   : %s" % (__file__))
    log.debug("AudioBookReader.common: __package__: %s" % (__package__))

#################
class AudioBookException(Exception):
   '''Error reading Audio Book'''
