# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
__license__   = 'GPL v3'
__copyright__ = '2015,2016,2017,2018,2019  DaltonST <DaltonShiTzu@outlook.com>'
__my_version__ = "1.0.75"   # Python 3 Compatibility.  Minimum Calibre Version 3.41.3

from PyQt5.Qt import QWidget

from calibre.utils.config import JSONConfig

from polyglot.builtins import unicode_type

# This is where all preferences for this plugin are stored
prefs = JSONConfig('plugins/multi_column_search')

# Set defaults
prefs.defaults['LAST_TAB_USED'] = unicode_type(0)

prefs.defaults['NAME1'] = unicode_type("title")
prefs.defaults['TEXT1'] = unicode_type("#work_title")
prefs.defaults['TYPE1'] = unicode_type("LABEL")
prefs.defaults['OPERATOR1'] = unicode_type("contains")
prefs.defaults['REGEX1'] = unicode_type("^.+$")
prefs.defaults['TRANSFORM_FUNCTION1'] = unicode_type("Compare: 'as-is'")
prefs.defaults['FUZZYWUZZY1'] = unicode_type("Fuzzy Equality Compare: None")

prefs.defaults['ANDORNOT'] = unicode_type("OR")

prefs.defaults['INTER_BOOK_SEARCH'] = unicode_type("False")

prefs.defaults['CROSS_LIBRARY_DUPLICATES_SEARCH'] = unicode_type("False")

prefs.defaults['ALL_AUTHORS_BOOKS'] = unicode_type("False")

prefs.defaults['USE_FINAL_FILTERS'] = unicode_type("False")

prefs.defaults['FINAL_FILTERS_LAST_SAVED'] = unicode_type("never")
prefs.defaults['FINAL_FILTERS_LAST_VALIDATED'] = unicode_type("never")

prefs.defaults['FINAL_FILTERS_PASSED_VALIDATION'] = unicode_type("True")

prefs.defaults['NAME2'] = unicode_type("authors")
prefs.defaults['TEXT2'] = unicode_type("#work_author")
prefs.defaults['TYPE2'] = unicode_type("LABEL")
prefs.defaults['OPERATOR2'] = unicode_type("contains")
prefs.defaults['REGEX2'] = unicode_type("^.+$")
prefs.defaults['TRANSFORM_FUNCTION2'] = unicode_type("Compare: 'as-is'")
prefs.defaults['FUZZYWUZZY2'] = unicode_type("Fuzzy Equality Compare: None")

prefs.defaults['REGEXVALUE_0'] = unicode_type("^.+$(?#This will match everything.  The ^ and $ are optional anchors.)")
prefs.defaults['REGEXVALUE_1'] = unicode_type(".+(?#For a user guide to Regular Expressions, refer to:  https://docs.python.org/2/library/re.html )")
prefs.defaults['REGEXVALUE_2'] = unicode_type(".+(?#For an easy, interactive way to learn REs, refer to:  https://pythex.org/ )")
prefs.defaults['REGEXVALUE_3'] = unicode_type("^[ABCD](?#Purpose:  Starts with  A,B,C or D  )")
prefs.defaults['REGEXVALUE_4'] = unicode_type("^B(?#Purpose:  Starts with a B  )")
prefs.defaults['REGEXVALUE_5'] = unicode_type("^[^ABD](?#Purpose:  Starts with any char except A, B, D  )")
prefs.defaults['REGEXVALUE_6'] = unicode_type("^.+L$(?#Purpose:   Ends with an L  )")
prefs.defaults['REGEXVALUE_7'] = unicode_type("[^a-c6](?#Purpose: matches any char except 'a', 'b', 'c' or '6'  )")
prefs.defaults['REGEXVALUE_8'] = unicode_type("[a]")
prefs.defaults['REGEXVALUE_9'] = unicode_type("Please note the 2 'I.C.?' checkboxes to the left.  'I.C.?' means 'Use re.IGNORECASE?' ")

prefs.defaults['REGEX_RADIO_COL1_0'] = unicode_type("True")
prefs.defaults['REGEX_RADIO_COL1_1'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL1_2'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL1_3'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL1_4'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL1_5'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL1_6'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL1_7'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL1_8'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL1_9'] = unicode_type("False")

prefs.defaults['REGEX_RADIO_COL2_0'] = unicode_type("True")
prefs.defaults['REGEX_RADIO_COL2_1'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL2_2'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL2_3'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL2_4'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL2_5'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL2_6'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL2_7'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL2_8'] = unicode_type("False")
prefs.defaults['REGEX_RADIO_COL2_9'] = unicode_type("False")

prefs.defaults['REGEX_IGNORECASE_1'] = unicode_type("True")
prefs.defaults['REGEX_IGNORECASE_2'] = unicode_type("True")


prefs.defaults["FINAL_FILTER_0"] =  unicode_type("['False', 'books: series_index', 'IS', '2', 'OR', '>=']")
prefs.defaults["FINAL_FILTER_1"] =  unicode_type("['False', 'identifiers: type', 'IS NOT', 'ddc', 'OR', 'EXISTENT']")
prefs.defaults["FINAL_FILTER_2"] =  unicode_type("['False', 'cc: #myserieslike', 'IS', 'Star Wars  [*]', 'OR', 'EXISTENT']")
prefs.defaults["FINAL_FILTER_3"] =  unicode_type("['False', 'cc: #mytextfixedsetofvalues', 'IS', 'Favorites', 'AND', 'LIKE']")
prefs.defaults["FINAL_FILTER_4"] =  unicode_type("['False', 'cc: #myyesno', 'IS', '', 'AND', 'False']")
prefs.defaults["FINAL_FILTER_5"] =  unicode_type("['False', 'cc: #myrating', 'IS NOT', '', 'AND', 'EXISTENT']")
prefs.defaults["FINAL_FILTER_6"] =  unicode_type("['False', 'cc: #original_title', 'IS', '', 'AND', 'EXISTENT']")
prefs.defaults["FINAL_FILTER_7"] = unicode_type("['False', 'authors: name', 'IS NOT', 'Smith', 'NOT', 'LIKE']")
prefs.defaults["FINAL_FILTER_8"] =  unicode_type("['False', 'tags: name', 'IS', 'Factual', 'NOT', 'LIKE']")
prefs.defaults["FINAL_FILTER_9"] =  unicode_type("['False', 'books: pubdate', 'IS', '2000-01-01', '', '<']")

prefs.defaults['SPECIAL_QUERY_ACTIVE'] = unicode_type("False")

prefs.defaults['RAW_SQL_QUERY_LAST_SAVED'] = unicode_type("")

prefs.defaults['COLUMN__0_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__1_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__2_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__1_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__4_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__5_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__6_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__7_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__8_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__9_WIDTH'] = unicode_type(1)
prefs.defaults['COLUMN__10_WIDTH'] = unicode_type(1)

prefs.defaults['BOOKS_VALID_FOR_POST_SEARCH_ACTIONS'] = unicode_type("[]")

prefs.defaults['OPTIONS_TEXT_ACTIVATE'] = unicode_type("False")
prefs.defaults['OPTIONS_COMPARE_FOUND_TEXT'] = unicode_type("False")
prefs.defaults['OPTIONS_COMPARE_FOUND_TEXT_CC'] = unicode_type("")
prefs.defaults['OPTIONS_COMPARE_FOUND_TEXT_REGEX'] = unicode_type("")
prefs.defaults['OPTIONS_UPDATE_FOUND_TEXT'] = unicode_type("False")
prefs.defaults['OPTIONS_UPDATE_FOUND_TEXT_CC'] = unicode_type("")
prefs.defaults['OPTIONS_UPDATE_FOUND_TEXT_REGEX'] = unicode_type("")

#--------------------------------------------------
#--------------------------------------------------
class ConfigWidget(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        return
#--------------------------------------------------
#--------------------------------------------------
    def validate(self):
        return True
#--------------------------------------------------
#--------------------------------------------------
#END of config.py

