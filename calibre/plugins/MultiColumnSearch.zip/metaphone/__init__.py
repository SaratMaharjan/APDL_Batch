# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
#~ from .metaphone import doublemetaphone, dm
display_name = "Metafone"
library_name = "metafone"
version = "0.5"
author = "Alastair Houghton"
author_email = "alastair@alastairs-place.net"
license = "BSD"
url = "https://github.com/al45tair/metaphone"
description = "A Python implementation of the double metaphone algorithms."