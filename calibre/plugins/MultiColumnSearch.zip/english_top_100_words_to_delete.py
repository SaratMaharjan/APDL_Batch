# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
__license__   = 'GPL v3'
__copyright__ = '2015,2016,2017,2018,2019  DaltonST <DaltonShiTzu@outlook.com>'
__my_version__ = "1.0.75"   # Python 3 Compatibility.  Minimum Calibre Version 3.41.3

def return_english_top_100_noun_list():
    top_100_nouns_set_singular = set(list(['time' , 'issue' , 'year' , 'side' , 'person' , 'kind' , 'way' , 'head' , 'day' , 'house' , 'man' , 'service' , 'thing' , 'friend' , 'woman' , 'father' , 'life' , 'power' , 'child' , 'hour' , 'world' , 'game' , 'school' , 'line' , 'state' , 'end' , 'family' , 'member' , 'student' , 'law' , 'group' , 'car' , 'country' , 'city' , 'problem' , 'community' , 'hand' , 'name' , 'part' , 'president' , 'place' , 'team' , 'case' , 'minute' , 'week' , 'idea' , 'company' , 'kid' , 'system' , 'body' , 'program' , 'information' , 'question' , 'back' , 'work' , 'parent' , 'government' , 'face' , 'number' , 'other' , 'night' , 'level' , 'mr' , 'office' , 'point' , 'door' , 'home' , 'health' , 'water' , 'person' , 'room' , 'art' , 'mother' , 'war' , 'area' , 'history' , 'money' , 'party' , 'storey' , 'result' , 'fact' , 'change' , 'month' , 'morning' , 'lot' , 'reason' , 'right' , 'research' , 'study' , 'girl' , 'book' , 'guy' , 'eye' , 'food' , 'job' , 'moment' , 'word' , 'air' , 'business' , 'teacher']))

    top_100_nouns_set = top_100_nouns_set_singular.union(set(list(['times' , 'issues' , 'years' , 'sides' , 'people' , 'kinds' , 'ways' , 'heads' , 'days' , 'houses' , 'men' , 'services' , 'things' , 'friends' , 'women' , 'fathers' , 'lives' , 'powers' , 'children' , 'hours' , 'worlds' , 'games' , 'schools' , 'lines ' , 'states' , 'ends' , 'families' , 'members' , 'students' , 'laws' , 'groups' , 'cars' , 'countries' , 'cities' , 'problems' , 'communities' , 'hands' , 'names' , 'parts' , 'presidents' , 'places' , 'teams' , 'cases' , 'minutes' , 'weeks' , 'ideas' , 'companies' , 'kids' , 'systems' , 'bodies' , 'programs' , 'information' , 'questions' , 'backs' , 'works' , 'parents' , 'governments' , 'faces' , 'numbers' , 'others' , 'nights' , 'levels' , 'misters' , 'offices' , 'points' , 'doors' , 'homes' , 'healths' , 'waters' , 'persons' , 'people', 'rooms' , 'arts' , 'mothers' , 'wars' , 'areas' , 'histories' , 'monies' , 'parties' , 'storey' 'story', 'stories' 'storeys', 'results' , 'facts' , 'changes' , 'months' , 'mornings' , 'lots' , 'reasons' , 'rights' , 'researchs' , 'studys' , 'girls' , 'books' , 'guys' , 'eyes' , 'foods' , 'jobs' , 'moments' , 'words' , 'airs' , 'businesses' , 'teachers'])))

    del top_100_nouns_set_singular

    return top_100_nouns_set
#END